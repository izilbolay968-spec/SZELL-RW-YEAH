# SZEELL RW — proyek Android

Aplikasi Android bernama **SZEELL RW** dengan panel DNS Server dan panduan Mobile Legends.

## DNS yang dimasukkan
- DNS utama: `221.126.236.36`
- DNS cadangan: `185.236.104.104`

Aplikasi menyediakan tombol salin untuk kedua IP dan pintasan ke pengaturan Wi-Fi Android. Aplikasi **tidak mengubah DNS diam-diam**. Untuk Wi-Fi, buka detail jaringan lalu ubah pengaturan IP/DNS sesuai dukungan perangkat; catat konfigurasi IP lama sebelum mengubahnya. DNS IP tidak dapat dimasukkan ke kolom Android **Private DNS** yang meminta hostname. Penggunaan DNS IP pada data seluler biasanya memerlukan aplikasi DNS berbasis VPN.

## Fitur
- Beranda gelap dengan nama SZEELL RW.
- DNS utama dan cadangan sesuai IP yang diberikan.
- Tombol salin DNS dan pintasan ke pengaturan Wi-Fi.
- Panel ML Tools berisi panduan koneksi dasar, tanpa cheat, auto-play, atau modifikasi game.
- Tidak ada bot Telegram.

## Membuat APK dari HP Android melalui GitHub Actions
APK belum dikompilasi di lingkungan ini. Workflow cloud disertakan agar APK debug dapat dibuat tanpa memasang Android SDK di HP.

1. Buka https://github.com dan masuk/daftar.
2. Buat repository baru bernama `SZEELL-RW`.
3. Unggah semua file/folder proyek dengan struktur tetap utuh, termasuk `.github/workflows/android.yml`.
4. Buka tab **Actions** dan jalankan workflow **Build SZEELL RW APK**.
5. Setelah sukses, buka hasil workflow dan unduh artifact `SZEELL-RW-debug-APK`.
6. Ekstrak ZIP di HP; file `app-debug.apk` ada di dalamnya. Buka file itu untuk instalasi dan izinkan instalasi dari sumber tersebut jika diminta.

Jika workflow gagal, buka log Actions dan periksa pesan error. File APK ini merupakan implementasi ulang awal, bukan salinan kode asli dari APK contoh.
