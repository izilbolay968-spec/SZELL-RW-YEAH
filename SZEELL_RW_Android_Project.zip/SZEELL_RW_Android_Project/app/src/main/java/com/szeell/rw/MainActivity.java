package com.szeell.rw;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.ClipboardManager;
import android.content.ClipData;
import android.content.Context;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    final int bg = Color.rgb(8,17,31), panel = Color.rgb(18,31,51), mint = Color.rgb(77,226,197), white = Color.WHITE, muted = Color.rgb(159,177,199);
    final String dnsPrimary = "221.126.236.36";
    final String dnsSecondary = "185.236.104.104";
    LinearLayout root, body;

    @Override public void onCreate(Bundle b) { super.onCreate(b); showHome(); }

    GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius); d.setStroke(1, Color.rgb(38,57,78));
        return d;
    }
    TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL); t.setPadding(0, 2, 0, 2);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        return t;
    }
    LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    void base(String subtitle) {
        root=column(); root.setBackgroundColor(bg); root.setPadding(20,18,20,20);
        ScrollView scroll=new ScrollView(this); body=column(); body.setPadding(0,8,0,24); scroll.addView(body);
        root.addView(text("SZEELL RW",26,mint,true));
        root.addView(text(subtitle,13,muted,false));
        View line=new View(this); line.setBackgroundColor(Color.rgb(38,57,78));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,1); lp.setMargins(0,14,0,8); root.addView(line,lp);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }
    void card(String title, String desc, View action) {
        LinearLayout c=column(); c.setPadding(16,14,16,14); c.setBackground(shape(panel,18));
        c.addView(text(title,17,white,true));
        TextView d=text(desc,14,muted,false); d.setGravity(Gravity.TOP);
        LinearLayout.LayoutParams dp=new LinearLayout.LayoutParams(-1,-2); dp.setMargins(0,6,0,12); c.addView(d,dp);
        if(action!=null)c.addView(action);
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2); cp.setMargins(0,8,0,8); body.addView(c,cp);
    }
    Button button(String label, Runnable run) {
        Button b=new Button(this); b.setText(label); b.setAllCaps(false); b.setTextColor(bg);
        b.setTypeface(null,Typeface.BOLD); b.setBackground(shape(mint,14)); b.setOnClickListener(v->run.run());
        return b;
    }
    Button secondaryButton(String label, Runnable run) {
        Button b=new Button(this); b.setText(label); b.setAllCaps(false); b.setTextColor(white);
        b.setBackground(shape(Color.rgb(30,48,70),14)); b.setOnClickListener(v->run.run());
        return b;
    }
    void copy(String value, String label) {
        ClipboardManager cm=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText(label,value));
        Toast.makeText(this,label+" disalin",Toast.LENGTH_SHORT).show();
    }
    void showHome() {
        base("DNS SERVER • ML TOOLS");
        TextView hero=text("TOOLS UNTUK KONEKSI & GAMING",20,white,true);
        hero.setPadding(0,14,0,6); body.addView(hero);
        body.addView(text("DNS pilihan kamu sudah dimasukkan. Salin alamat server lalu atur pada jaringan yang sedang digunakan.",14,muted,false));
        card("🌐  DNS SERVER KUSTOM",
             "DNS UTAMA\n"+dnsPrimary+"\n\nDNS CADANGAN\n"+dnsSecondary,
             button("SALIN DNS UTAMA",()->copy(dnsPrimary,"DNS utama")));
        card("DNS CADANGAN",dnsSecondary,button("SALIN DNS CADANGAN",()->copy(dnsSecondary,"DNS cadangan")));
        card("⚙️  CARA MENGAKTIFKAN",
             "Untuk Wi-Fi: buka detail jaringan yang tersambung, ubah IP Settings menjadi Static jika diperlukan, lalu isi DNS 1 dan DNS 2. Catat pengaturan IP lama sebelum mengubahnya.\n\nAlamat DNS berbentuk IP tidak bisa dimasukkan ke kolom Android Private DNS yang meminta nama host. Untuk data seluler, pengaturan DNS IP biasanya membutuhkan aplikasi VPN DNS khusus.",
             button("BUKA PENGATURAN WI-FI",()->openWifiSettings()));
        card("🎮  ML TOOLS",
             "Panel panduan koneksi untuk Mobile Legends: Bang Bang. DNS tidak menjamin ping lebih rendah dan tidak mengubah mekanik game.",
             button("BUKA ML TOOLS",()->showMl()));
        card("ℹ️  STATUS",
             "Aplikasi menyimpan alamat DNS yang kamu berikan dan menyediakan tombol salin. DNS belum diterapkan otomatis oleh aplikasi.", null);
    }
    void openWifiSettings() {
        try { startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS)); }
        catch(Exception e) { try { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
        catch(Exception ignored) { Toast.makeText(this,"Buka Setelan Android secara manual.",Toast.LENGTH_LONG).show(); } }
    }
    void showMl() {
        base("ML GAMING TOOLS");
        card("🎮  PANEL ML","Utilitas ringan untuk pemain Mobile Legends: Bang Bang.",null);
        card("🌐  DNS KUSTOM","DNS utama: "+dnsPrimary+"\nDNS cadangan: "+dnsSecondary+"\nSalin alamat dan atur pada jaringan Wi-Fi jika didukung.",button("SALIN DNS UTAMA",()->copy(dnsPrimary,"DNS utama")));
        card("📶  PANDUAN KONEKSI","Gunakan jaringan yang stabil, hentikan unduhan besar saat bermain, dan pilih server game yang sesuai. Mengganti DNS biasanya lebih berpengaruh pada pencarian nama domain daripada latensi pertandingan.",button("BUKA PENGATURAN WI-FI",()->openWifiSettings()));
        card("🛡️  PRIVASI","Aplikasi ini tidak meminta login Mobile Legends, tidak menggunakan cheat, auto-play, atau mengirim data akun.",button("KEMBALI KE BERANDA",()->showHome()));
    }
}
